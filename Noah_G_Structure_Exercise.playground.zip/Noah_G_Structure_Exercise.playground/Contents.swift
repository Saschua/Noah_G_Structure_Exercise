import UIKit

struct engines {
    var engineone: String = " "
    var enginetwo: String = " "
    var enginethree: String = " "
}
var allengines = engines(engineone: "V4", enginetwo: "V6", enginethree: "V8")
print (allengines)
